var fs = require('fs');
var lista = JSON.parse(fs.readFileSync('./lista.json'));



if(lista.valores == 0 )
{
  console.log("Tente Novamnte mais tarde.");
  process.exit(-1);
}
else

{
	var posicoes = [];
  var posicoes_int = [];
  var inicio = lista.valores[0];
  var final = [];
  var resultado = "";
		for(var a = 0; a < lista.valores.length;  a++)
		{
			if(lista.valores[a + 1] - lista.valores[a] != 1)
      {
        //posicoes_int.push(a);
        fim = lista.valores[a];
        if(fim == inicio)
        {
          resultado += "[" + inicio + "]";
        }
        else {
          resultado += "[" + inicio + "-" + fim + "], ";
        }
        inicio = lista.valores[a+1];
      }
		}
		//for(var i = 0; )
		console.log(resultado);		//console.log("[" + lista.valores[a] + "]" );
fs.writeFile(arquivo, dados, funtion(){})

}
